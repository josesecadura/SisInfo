# Práctica 3 

## Descripción general
## Requisitos
- Cuenta y proyecto de Neon.
- Cliente `psql` instalado localmente.
- Cadena de conexión:
  psql 'postgresql://neondb_owner:npg_1zdNbswgxUm0@ep-bold-violet-agv6welv-pooler.c-2.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'
- Para ejecutarlos los archivos:
  psql -f ddl.sql
  psql -f seed.sql

## Estructura
sources/
|__ scripts/
    |__ ddl.sql     # Creación de esquema y tablas
    |__ seed.sql    # Datos iniciales
    |__ README.md   # Este archivo
memoria.pdf


## Autores  
Jose Secadura Del Olmo
Chloé Bolle-Reddat
Sergio Saura Oliva

